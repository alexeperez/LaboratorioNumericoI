% Analisis de condicionamiento
% Sistema lineal Ax=b

% Ejercicio 1. Dados x=[4 1 2], A=[2 4 5;6 9 8;4 5 3]
% a. Calcular b:=A*x
% b. Calcular xt=inv(A)*b
% c. Calcular el error relativo entre x y xt. Que puede concluir?
% d. Realice un calculo similar considerando x=[1 1 2] A=[1 3 5;2 5 3;1 7 3]
x=[4 1 2]';
A=[2 4 5;6 9 8;4 5 3];
b=A*x;
xt=A\b;
er1=norm(x-xt,2)/norm(x,2); %norm(x,p) norma de Holder
er1;

x=[1 1 2]';
A=[1 3 5;2 5 3;1 7 3];
b=A*x;
xt=A\b;
er2=norm(x-xt,2)/norm(x,2);
er2;

% Ejercicio 2. 
% Una matriz se dice de Hilbert si (aij)=1/(i+j-1) 
% a. Construya una matriz de Hilbert de 10x10
% b. Utilice el comando hilb y compare con a)
% c. Crear matrices de Hilbert de dimension 9, 12, 15
% d. Calcular K(A) para cada matriz de c) (Utilice norm(A,Inf)
% e. Utilice el comando cond y compare con d)
crear_hilbert(10);
hilb(10);

H1=hilb(9);
H2=hilb(12);
H3=hilb(15);

K_H1= norm(H1,inf)*norm(inv(H1),Inf);
K_H2= norm(H2,Inf)*norm(inv(H2),Inf);
K_H3= norm(H3,Inf)*norm(inv(H3),Inf);

K_H1;
K_H2;
K_H3;
cond(H1,Inf);
cond(H1,1);



% Ejercicio 3. 
% Cree una matriz de Hilbert H de dimension 3 y b=1:3
% a. Calcule x, mediante Hx=b
% b. Calcule xt si las componentes de b aumentan en 
% 0.1, 0.01, 0.001, sqrt(eps)
% Genere una tabla resumen en la que conste el 
% incremento de b y el error relativo entre x y xt
H=hilb(3);
b=1:3;
b=b';
x=H\b;
incr=[0.1 0.01 0.001 sqrt(eps)];
k=length(incr);
er=zeros(k,1);
disp('incr  er ')
for i=1:k
    bt=b+incr(i);
    xt=H\bt;
    er(i)=norm(x-xt,2)/norm(x,2);
    fprintf('%2.5f \t %2.6f \n',incr(i),er(i))
end


% Ejercicio 4. 
% Cree una matriz de Hilbert H de dimension 3 y b=1:3
% a. Calcule x, mediante Hx=b
% b. Calcule xt si las componentes de H aumentan en 
% 0.1, 0.01, 0.001, sqrt(eps)
% Genere una tabla resumen en la que conste K(H) 
% incremento de A y el error relativo entre x y xt
H=hilb(3);
b=1:3;
b=b';
x=H\b;
incr=[0.1 0.01 0.001 sqrt(eps)];
k=length(incr);
K_H=zeros(k,1);
er=zeros(k,1);

disp('K(H)	incr  er ')
for i=1:k
    Ht=H+incr(i);
    xt=Ht\b;
    K_H(i)=cond(Ht,Inf);
    er(i)=norm(x-xt,2)/norm(x,2);
    fprintf('%2.5f \t %2.6f \t %2.7f \n',K_H(i),incr(i),er(i))
end

