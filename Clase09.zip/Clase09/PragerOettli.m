% Indicador de PragerOettli
% Se satisface error <= PragerOettli

% Inputs: A, b, xt: xtecho (vectores columna)

function po=PragerOettli(A,b,xt)
 r = b-A*xt;
 aux = abs(A)*abs(xt)+abs(b);
 po = max(abs(r)./aux);
 po;
end