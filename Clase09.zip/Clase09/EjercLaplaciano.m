% Ejercicio metodos iterativos clasicos
% error vs indicador de Praguer-Oettli

% Genramos u como la solucion exacta de Au = b
n = 9;
x = 0.1:0.1:0.9;
y = x;
v = zeros(n,n);
for j=1:n
   for i=1:n
          v(i,j)=(x(i)-1)*(y(j)-1)*x(i)*y(j);
   end
end
u = reshape(v,81,1);
A = mlaplace(81);
b = A*u;

% Resolvemos Au = b mediante metodos iterativos
x0 = zeros(81,1);
tol=eps;

% Jacobi
[u1, k1]=Jacobi(A,b,x0,tol);
error1(u,u1);
PragerOettli(A,b,u1);

% Gauss Seidel
[u2, k2]=GaussSeidel(A,b,x0,tol);
error1(u,u2);
PragerOettli(A,b,u2);
