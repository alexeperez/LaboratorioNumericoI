% METODO DE JACOBI
% A = L + D + U
% x(k+1) = -D^-1 (L + U) x(k) + D^-1 b

function[x, k]=Jacobi(A,b,x0,tol)
L=tril(A,-1);
U=triu(A,1);
D=diag(diag(A));
%valor inicial
x=x0;
%iteracion
k=1;
%residuo
r=b-A*x;
while norm(r)>tol
    k=k+1;
    x=-inv(D)*(L+U)*x+inv(D)*b; %m�todo iterativo
    r=b-A*x;
end
x,k; %mostrar x y k
end

