% Sustituci�n Regresiva:
% U matriz triangular superior Rnxn
% b vector en Rn
% Resultado: x tal que Ux=b
function [x] = sust_reg(U,b)
[n,n]=size(U);
x=zeros(n,1);
for i=n:-1:1
    suma=0;
    for k=i+1:n
        suma=suma+x(k)*U(i,k);
    end
    x(i)=(1/U(i,i))*(b(i)-suma);
end
end
