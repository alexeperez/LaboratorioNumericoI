% Sustitucion regresiva 
U=[34 3 87 6; 0 6 3 9; 0 0 42 13; 0 0 0 29]
b=[71 89 24 60]
x=sust_reg(U,b)
%Validar con
U\b'

% Sustitucion progresiva
L=[34 0 0 0; 6 3 0 0; 42 13 29 0; 34 3 87 6]
b=[71 89 24 60]
x=sust_prog(L,b)
%Validar con
L\b'

% Factorizacion LU
A=[34 5 7 1; 6 3 12 20; 42 13 29 0; 34 3 87 6]
[L,U]=fact_LU(A)


% Solucion Sistema Lineal Ax=b Fact LU
A=[34 5 7 1; 6 3 12 20; 42 13 29 0; 34 3 87 6]
b=[7 8 2 1]
solAx_LU(A,b)
%Validar con
A\b'

% eliminacion gauss
A=[34 5 7 1; 6 3 12 20; 42 13 29 0; 34 3 87 6]
b=[7 8 2 1]
elim_gauss(A,b)

