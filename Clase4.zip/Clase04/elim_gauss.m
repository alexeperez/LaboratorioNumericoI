% Solucion de Sistemas Lineales eliminacion gaussiana
% A matriz Rnxn
% b vector en Rn
% Resultado: A tal que Ax=b

function[A]=elim_gauss(A,b)
[n,n]=size(A);
A=[A,b'];
for k=1:n-1  
    for j=k+1:n
        A(j,:)=A(j,:)-A(j,k)*(A(k,:)/A(k,k));
    end
end
A=A;
end