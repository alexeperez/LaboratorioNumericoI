% Solucion de Sistemas Lineales Factorizacion LU
% A matriz Rnxn
% b vector en Rn
% Resultado: x tal que Ax=b
function[x]=solAx_LU(A,b)
[L,U]=fact_LU(A);
y=sust_prog(L,b);
x=sust_reg(U,y);
end