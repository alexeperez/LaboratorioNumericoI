% Sustituci�n Progresiva:
% L matriz triangular inferior Rnxn
% b vector en Rn
% Resultado: x tal que Lx=b
function [x] = sust_prog(L,b)
[n,n]=size(L);
x=zeros(n,1);
for i=1:n
    suma=0;
    for k=1:i-1
        suma=suma+x(k)*L(i,k);
    end
    x(i)=(1/L(i,i))*(b(i)-suma);
end
end