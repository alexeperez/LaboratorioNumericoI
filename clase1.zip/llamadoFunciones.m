
y = [12.7, 45.4, 98.9, 26.6, 53.1];
prom = promedio(y);


x = [12.7, 45.4, 98.9, 26.6, 53.1];
[prom, sd] = descriptivos(x)