% ENTORNO
% Consola
% Workspace 
% Directorio de trabajo

% CREACION DE OBJETOS
% Simbolo de asignacion: = 
% Simbolo de comparacion: == 
% Variable constante
a = 2+1;
b = 10*pi;
c = sqrt(16);
x = a+b+c;
y = log(x);
z = sin(pi);
chr = 'LabI';

bool1 = a==4;
bool2 = a==3;

% Vectores
% vector fila
v_f = [1 5 3 6];
% vector columna
v_c = [-1 3.2 7 2.1]';
% componentes de un vector
% se utiliza x(i) para extraer la componente i de x
comp2 = v_f(2);
% longitud de un vector
length(v_f);
long = length(v_f);

% MATRICES
A = [1 3 1; 0 2 0];
B = [-2 1 2; -3 0 1];

% dimension
size(A);
dim = size(A);
dim(2);



% WORKSPACE
% who, whos Enlista los objetos
% save VarsLabI.mat guarda todos los objetos creados para un posterior uso

% clear a remover el objeto a
% clear all remover todos los objetos

% load VarsLabI.mat lee los objetos todos los objetos del archivo 
% clc limpiar consola