% SENTENCIA IF

% Hallar un determinado valor superior a un limite
lim = 0.75;
v = rand(10,1);

if any(v > lim)
    disp('Existe al menos un valor que supera a lim.')
else
    disp('Todos los valores son menores a lim.')
end


% Concatenar matrices iguales
A = ones(2,3);
B = rand(3,4);
% Si size(A)==size(B), concatenar A y B
% caso contrario imprimir una advertencia y retornar una matriz vacia.

if isequal(size(A),size(B))
   C = [A; B];
else
   disp('A y B no tiene la misma dimension.')
   C = [];
end





% SENTENCIA FOR
% Media para todas las columnas 
A = rand(5, 4);
dim = size(A);
v1 = [];
for i = 1:dim(2)
    media = mean(A( : , i));
    v1(i) = media;
end

% Media para todas las columnas 
A = rand(5, 4);
dim = size(A);
v2 = [];
for i = 1:dim(1)
    suma = sum(A(i, : ));
    v2(i) = suma;
end
