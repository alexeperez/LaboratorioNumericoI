% GRAFICOS 2D

x = 0:pi/100:2*pi;
y = sin(x);

% Figura en ventana nueva
figure 
plot(x,y)
grid

x = linspace(-2*pi,2*pi);
y1 = sin(x);
y2 = cos(x);

figure
plot(x,y1,x,y2)

title('Figura 1')
xlabel('var')
ylabel('f(var)')
legend('sen x', 'cos x')


% GRAFICOS 3D
x = linspace(-pi, pi,50);
y = linspace(-pi, pi,50);
[X, Y] = meshgrid(x, y);
z = sin(1.1 * (X.^2+Y.^2))./(X.^2+Y.^2);

figure
surf(x, y, z)
title('Superficie')
grid