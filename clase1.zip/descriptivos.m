% Funcion con varios outputs
% media, desviacion standar
function [m, s] = descriptivos(x)
  n = length(x);
  m = sum(x)/n;
  s = sqrt(sum((x-m).^2/n));
end
