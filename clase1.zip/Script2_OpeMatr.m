% SUBMATRICES
A = [1:4 ; 5:8; 9:12];
B = [-2 1 2; -3 0 1; 1 1 2];

% fila 1
A(1,:);
% filas 1 y 2
A([1 2],:);

% columna 2
A(:,2);
% columnas 2 y 4
A(:,[2 4]);
% columnas 1, 2 y 3
A(:,[1 2 3]);
A(:,1:3);

% filas 1 y 2, columnas 1 y 4 de B
C = B([1 2], [1 2]);
% filas 1 y 3, columnas 2 y 4 de A
D = A([1 3], [2 4]);

% OPERACIONES MATRICES
R1 = C+D;
R2 = C-D;
R3 = C*D;

% MATRIZ TRANSPUESTA
At = A'

% VALORES Y VECTORES PROPIOS
A = [1 -1 3; 5 6 8; 0 -8 1];
val_prop = eig(A);
[val_prop vec_prop] = eig(A);

% MATRIZ DIAGONAL
% Extrae la diagonal de una matriz
diag(A, 0);
diag(A, 1);
diag(A, -1);

% Crea una matriz diagonal de un vector
v = diag(A);
diag(v);
diag(v, -1);

% CONCATENAR MATRICES
A = [1 1; -2 -2];
B = [3 3; -4 -4];
v = [0 0];
% por filas
cat(1, A, B)
% por columnas
cat(2, A, B)

cat(1, A, v)