% FUNCIONES
% Sintaxis

% function [y_1,...,y_n] = myfun(x_1,...,x_m)
    % sentencia 1
    % sentencia n
    % calculo de y_1,...,y_n
% end

% x_1,...,x_m inputs
% y_1,...,y_n outputs
% myfun nombre de la funcion

% declaracion de la funcion
% Funcion promedio 
function y = average(x)
if ~isvector(x)
    error('El input debe ser un vector')
end
y = sum(x)/length(x); 
end




% Funciones Matlab
% https://www.mathworks.com/help/matlab/functionlist.html

