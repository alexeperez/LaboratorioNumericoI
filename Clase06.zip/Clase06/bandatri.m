% METODO DE SOLUCION DE MATRICES BANDA TRIDIAGONAL

clc  %permite borrar el area de trabajo
clear  %permite borrar las variables almacenadas
format long %permite utilizar la maxima capacidad de la maquina

fprintf('                     METODO DE SOLUCION DE MATRICES BANDA TRIDIAGONAL\n\n\n');
%fprintf me permite ingresar comentarios de manera textual que pueden
%orientar al usuario en el uso del programa

%input es un comando de solicitud de entrada de datos del usuario.
a=input('Ingrese la diagonal principal\n');
b=input('\nIngrese la diagonal superior\n');
c=input('\nIngrese la diagonal inferior\n');
d=input('\nIngrese el vector de terminos independientes\n');
%los vectores de deben ingresar, como vectores horizontales sin utilizar el
%punto y coma ';'
n=length(a); %numero de elementos del vector a
for k=1:(n-1)
    m(k)=c(k)/a(k); %calculo de los multiplicadores
    c(k)=0;
    a(k+1)=a(k+1)-m(k)*b(k); %nuevo vector a (diagonal principal)
    d(k+1)=d(k+1)-m(k)*d(k); %nuevo vector d (Terminos independientes) 
end
fprintf('\nVECTOR FINAL a(Diagonal principal)=\n')
%a continuacion de utiliza una instruccion for, para mostrar el usuario, 
%los resultados de una manera mas ordenada
    for i=1:n     
    ai=a(1,i);
    fprintf('a%g=',i)
    disp(ai);
    end
    fprintf('\nVECTOR FINAL d(Diagonal inferior)=\n')
%a continuacion de utiliza una instruccion for, para mostrar el usuario, 
%los resultados de una manera mas ordenada
    for i=1:n     
    di=d(1,i);
    fprintf('d%g=',i)
    disp(di);
    end
    %caculo de las x's (Variables)
x(n)=d(n)/a(n);
x(n-1)=(d(n-1)-b(n-1)*x(n))/a(n-1);
for i=(n-2):-1:1
    x(i)=(d(i)-b(i)*x(i+1))/a(i);
end
%a continuacion de utiliza una instruccion for, para mostrar el usuario, 
%los resultados de una manera mas ordenados. 
  fprintf('\n\nLa solucion de X1 hasta Xn es:\n');
for i=1:n
    xi=x(1,i);
    fprintf('\nX%g=',i)
    disp(xi);
end