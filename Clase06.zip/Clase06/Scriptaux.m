% Factorizacion cholesky
A=[4 3 2 1; 3 3 2 1; 2 2 2 1; 1 1 1 1]
[R,Q]=fact_QRh(A)
Q*R
A