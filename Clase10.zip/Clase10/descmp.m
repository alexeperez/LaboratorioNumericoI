% METODO DEL DESCENSO MAS PROFUNDO
% A Rnxn sdp, b Rn, x0 Rn
% x(k) solucion aproximada de Ax=b

function[x, k]=descmp(A,b,x0,tol)
[n,n] = size(A);
k=0;
x=x0;
r=b-A*x;
while norm(r)>tol
    alpha= (r'*r)/(r'*A*r); 
    x= x + alpha*r;
    r=b-A*x;
    k=k+1;
end
end
