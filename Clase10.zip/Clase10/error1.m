% Error
% Se satisface error <= PragerOettli
% Inputs: x, xt: xtecho

function e=error1(x,xt)
 aux=abs(x-xt);
 e=max(aux./abs(x));
end