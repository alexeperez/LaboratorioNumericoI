% Ejercicio metodos iterativos clasicos
% error vs indicador de Praguer-Oettli

% Genramos u como la solucion exacta de Au = b
n = 9;
x = 0.1:0.1:0.9;
y = x;
v = zeros(n,n);
for j=1:n
   for i=1:n
          v(i,j)=(x(i)-1)*(y(j)-1)*x(i)*y(j);
   end
end
u = reshape(v,81,1);
A = mlaplace(81);
b = A*u;

% Resolvemos Au = b mediante metodos iterativos
x0 = zeros(81,1);
tol=0.0001;

% Gauss Seidel
[u1, k1]=GaussSeidel(A,b,x0,tol);
error1(u,u1)

% sor
w=0.1;
[u2, k2]=sor(A,b,x0,tol,w);
error1(u,u2)

% w optimo
valp = eig(A);
w=2/(max(valp)+min(valp));
[u3, k3]=sor(A,b,x0,tol,w);
error1(u,u3)

% Descenso mas profundo
[u4, k4]=descmp(A,b,x0,tol);
error1(u,u4)
