% METODO DE GAUSS SEIDEL
% A = L + D + U
% x(k+1) = (I - (D + L)^-1 A) x(k) + (D + L)^1 b

% SOR
% c = (D + L)^1 b
% x(k+1) = (wB + (1-w)I) x(k) + w c
function[x, k]=sor(A,b,x0,tol,w)
[n,n] = size(A);
D=diag(diag(A));
L=tril(A,1);

x=x0;
k=0;
r=b-A*x;
while norm(r)>tol
    k=k+1;
    x= x + ((D/w)+L)\r;
    r=b-A*x;
end
end
