% METODO DE GAUSS SEIDEL
% A = L + D + U
% x(k+1) = (I - (D + L)^-1 A) x(k) + (D + L)^1 b

function[x, k]=GaussSeidel(A,b,x0,tol)
[n,n] = size(A);
M=tril(A);
U=triu(A,1);
B=(eye(n) - inv(M)*A);

x=x0;
k=1;
r=b-A*x;
while norm(r)>tol
    k=k+1;
    x=B * x + M\b;
    r=b-A*x;
end
x,k;
end
