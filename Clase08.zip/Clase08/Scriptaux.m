
A=mlaplace(4)
h=0.2
f=[10;10;10;10]
b=h^2*f

x0=[0;0;0;0]
tol=0.00001
[x1 k1]=Jacobi(A,b,x0,tol)

x=[0;0;0;0]
tol=0.00001
[x2 k2]=GaussSeidel(A,b,x,tol)

c=b'/A
