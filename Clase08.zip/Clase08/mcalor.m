function A=mcalor(n)
v=ones(1,n-1);
A=2*eye(n)-diag(v,1)-diag(v,-1);
A;
end