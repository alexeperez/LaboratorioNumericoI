function y = f1(x)
y = 2/(x*(sqrt(x+(1/x))+sqrt(x-(1/x))));
end