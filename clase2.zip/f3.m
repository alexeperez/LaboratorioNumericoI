function y = f3(x)
y = sqrt((2*x)-(2*sqrt(x+(1/x))*sqrt(x-(1/x))));
end