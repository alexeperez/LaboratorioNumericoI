% ANALISIS DE ERRORES
% formato visualizacion de numeros
format long %(15 decimales)
pi
format short %(4 decimales)
pi
%short e %notaci�n cient�fica con 4 decimales
%long e  %notaci�n cient�fica con 15 decimales
%rat     %n�meros racionales como fraccion

% Infinito
1/0
1/0==Inf

0/0
Inf/Inf % NaN (Not a Number)


% Precision en Matlab
% eps: epsilon (precision) de maquina
% eps=diferencia entre 1 y el n�mero de punto
% flotante inmediatamente superior
eps
eps(1)
(1+eps)-1
% eps depende el numero (relativo)
eps(5)
(5+eps)-5

% Operaciones de punto flotante
% No asociativas
% Ejercicio
% ((((a+eps)+eps)+eps)+...+eps") ~= a+(eps+...+eps");
% suma1_e(2, 20)==suma2_e(2,20)

% Acumulacion de errores por redondeo
% Ejemplo
x=15;
y1= x*(sqrt(x+1)-sqrt(x))
y2= x/(sqrt(x+1)+sqrt(x))
y1 - y2

% como calcular f(x)=sqrt(x+(1/x))-sqrt(x-(1/x))
% para que sea numericamente mas estable
x=10e50;
f2(x);
f1(x);
f3(x);
f4(x); 

