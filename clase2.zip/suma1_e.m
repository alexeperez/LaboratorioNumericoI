function s = suma1_e(a, n)
s=a;
for i=1:n
    s=s+eps;
end
end