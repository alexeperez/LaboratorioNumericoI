function s = suma2_e(a, n)
e = 0;
for i=1:n
    e=e+eps;
end
s=a+e;
end