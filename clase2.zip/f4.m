function y = f4(x)
y = (sqrt(x^2+1)-sqrt(x^2-1))/sqrt(x);
end