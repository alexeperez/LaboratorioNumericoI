function y = f2(x)
y = sqrt(x+(1/x))-sqrt(x-(1/x));
end