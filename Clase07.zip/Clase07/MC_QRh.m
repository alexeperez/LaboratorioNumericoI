% MINIMOS CUADRADOS MEDIANTE FACT QR HOUSEHOLDER

function x=MC_QRh(A,b)
Q=zeros(size(A));
R=zeros(size(A));
[Q,R]=fact_QRh(A);
C=Q'*b;
x=sust_reg(R,C);
end