% FACTORIZACION CHOLESKY
function[L]=cholesky(A)
[n,m]=size(A);
L=zeros(n);
for k=1:n
    suma1=0;
    for p=1:k-1
        suma1=suma1+(L(k,p))^2;
    end
    L(k,k)=sqrt(A(k,k)-suma1);
    for i=k+1:n
        suma2=0;
        for p=1:k-1
            suma2=suma2+L(i,p)*L(k,p);
        end
        L(i,k)=(A(i,k)-suma2)/L(k,k); 
    end
end
end   