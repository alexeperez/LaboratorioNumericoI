% FACTORIZACION QR HOUSEHOLDER
% Matriz A Rnxn
% Q ortogonal y R triangular superior tal que A = QR

function[A,Q]=fact_QRh(A)
[n,m]=size(A);
Q=eye(n);
for k=1:n-1
    % H es Qk
    H=eye(n);
    % a
    a=A(k:n,k);
    % u
    norm_a=norm(a,2);
    e1=[1;zeros((length(a)-1),1)];
    u= a+sign(a(1))*norm_a*e1;
    % beta
    beta=1/(norm_a*(norm_a+abs(a(1))));
    
    H(k:n,k:n)=H(k:n,k:n)-beta*u*u';
    Q=Q*H;
    % columnas k y k+1 a n
    A(k:n,k)=-sign(a(1))*norm_a*e1;
    A(k:n,k+1:m)=A(k:n,k+1:m)-beta*u*(u'*A(k:n,k+1:m));
end
